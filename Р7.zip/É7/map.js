function map (array, operation) {
    var arrayCopy = []
    for (let item of array) {
        arrayCopy.push(operation(item))
    }
    return arrayCopy
}

let xx = map([1,2,3,4,5,6], (a) => a*a)
console.log(xx)