function User(name) {
    this.name = name
    this.getThis = function(){console.log(this)}
}

let user = new User('Alex')

user.getThis()
array = [1, 2, 3, 4]

console.log(array)
Array.prototype.getThis = user.getThis

array.getThis()

function getName() {
    console.log(this.name)
}
getName.call(user)
getName.apply(user)

function sum() {
    let result = 0
    for (let i of arguments) {
        result+=1
    }
    return result
}
console.log("sum", sum(1, 2,3,5,456,3453,5345))

function sum2() {
    return Array.prototype.reduce.call(arguments, (a, b) => a + b)
}
console.log("sum2", sum2(1, 2,3,5,456,3453,5345))

function sum3() {
    return [...arguments].reduce((a, b) => a + b)
}
console.log("sum3", sum3(1, 2,3,5,456,3453,5345))