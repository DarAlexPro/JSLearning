let board = { CellsCount: 8, RowsCount: 4, BlackCell: "#", WhiteCell: '_' }

while (board.RowsCount) {
    let row = ''
    for (let cell = 0; cell < board.CellsCount; cell++) {
        row += (cell + board.RowsCount) % 2 ? board.WhiteCell : board.BlackCell
    }
    console.log(row)
    board.RowsCount--
}