// '5 + 6' => 5, 6, '+'

function parse(source) {
    let op = source.match(/[:\+\-\*\/\\]/)
    let nums = source.match(/\d+([,.]\d+)?/g)
    console.log(`${source} : `, nums[0], nums[1], op[0])
}

function parse(str) {
    let a = ''
    let b = ''
    let op = ''
    str = str.replaceAll(' ', '') 
    
    for (let i of str){
        console.log( +i )
        if (i == '-' || (typeof +i == 'number' && !Number.isNaN(+i)) )
        // if ('-0123456789.'.includes(i)) 
        {
            if (!op){
                a += i
            } else {
                b += i
            }    
        } else {
            op = i
        }
        
    }

    return [+a, +b, op]
}

console.log(parse('23 / 56'))

parse('5/6')
parse('5 + 6')
parse(' 5 - 6')
parse(' 5 + 6 ')
parse(' 5 :6 ')
parse(' 5 *6 ')
parse(' 5* 6 ')
parse(' 55* 6 ')
parse(' 55,98* 6 ')
parse(' 55.98* 0,256 ')
parse(' 55* 6000 ')