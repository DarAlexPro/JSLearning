// var x = 5 // global visiblity
// let y = 6 // local visiblity

// const A = 3

// c = 54 // var c = 54

// // -- строки ---
// x = 'hello world'
// x = "Привет, мир!"
// x = `${y} - четное число` // форматированная строка

// // -- числа --
// x = 100

// // -- Булевы значения --
// x = false
// x = true

// // -- системные типы данных ---
// x = null       //  
// x = undefined  // системный тип данных, которая определяет, что в переменную еще не записано

// // массивы и коллекции
// let array = [1, 2, 3, 4, 72] // индексация с 0!
// array[0] // => 1
// array.length  // => 5
// array.push(556) 

// let array2 = array // таким образом, мы получим две ссылки на один и тот же массив. И если попытаемся изменить один из них, соответственно, автоматически изменим и другой. Но это очевидно, так же как и в С#

// // Объекты
// let point = {x: 34, y: 56}
// point.x  => 34
// point.z = 345 // {x: 34, y: 56, z: 345}
// point['Расстояние до 0'] = 23453 // {x: 34, y: 56, z: 345, 'Расстояние до 0': 23453}

// условия
let x = 0
if (x >= 5) {
    console.log(`x >= 5, потому что x = ${x}`)
} else if (x == 0) {
    console.log(`А теперь x = ${x}`)
}
else {
    console.log(`x < 5. А верно! Ведь x = ${x}`)
}

// Возможные типы сравнений 
// let x, y
// x > y
// x >= y
// x < y
// x <= y
// x == y => сравнение только по значению. Например, 2 будет равно '2'
// x === y => сравнение по типу и значению. Например, 2 будет равно 2. При этом 2 не равно '2'
// x != y
// x !== y


// Обрати внимание! 
console.log( 3 === +'3') // => true! Здесь производится скрытое преобразование к типу Int!
console.log( 3 === '3') // => false

// как записать несколько условий
// x > 5 && x < 3
// x > 5 || x < 3

let a = 1 // 1,2,3
switch (a) {
    case 1:
        console.log(a)
        break;
    case 2:
        console.log(a)
        break;
    case 3: 
        console.log(a)
        break;
    default:
        console.log('a не равно 1, 2, 3')
            break;
}

// циклы или повторения
array = [1,2,3,4,5,6,7,]

for (let index = 0; index < array.length; index++) {
    if (index % 2) {
        console.log(array[index]);
    }    
}

console.log('---Альтернативный вариант работы массива')
for (let el of array) {
    console.log(el)
}

console.log('----перебор строки')
for (let el of 'array') {
    console.log(el)
}

point = {x: 1, y: 2}
console.log('-----Перебор объекта')
for (let key in point) {
    console.log(key, point[key])
}

// оператор of - для перебора по индексу
// а оператор in используется для перебора ключей объекта или массива. 

x = 10
while (x) {
    console.log(x)
    x--
}

console.log("---- Изучаем функции ---- ")

function sum(a, b) {
    return a + b;
}

console.log(sum(3, 56))