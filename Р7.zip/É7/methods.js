let arr = [1, 2, 5, 7]

console.log(arr)
console.log(arr.length)

let arr2 = new Array(2,4,6,8, 10)
console.log(arr2)
console.log(arr2.length)

arr.push(9, 11, 13)
console.log(arr)

console.log(arr.push)
console.log(`arr.push === Array.prototype.push : ${arr.push === Array.prototype.push}`)
console.log(`arr is array? ${Array.isArray(arr)}`)

function x() {
    console.log(Array.from(arguments))
}

x(1231,13,1234,1234123,2345624356,234523452345,2345)

console.log(Object.keys(Array.prototype))