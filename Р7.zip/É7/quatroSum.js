function sum(a, b, c, d) {
    let result = 0
    if (a !== undefined) result += a
    if (b !== undefined) result += b
    if (c !== undefined) result += c
    if (d !== undefined) result += d

    return result
}

console.log(sum())
console.log(sum(1))
console.log(sum(1, 2))
console.log(sum(1, 2, 3))
console.log(sum(1, 2, 3, 4))