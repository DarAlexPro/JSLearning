function find(array, filter) {
    for (let item of array) {
        if (filter(item)) return item
    }
}

console.log("Найди 2 =>", find([1, 2, 3, 4], x => x == 2))
console.log("Найди первое число, делящееся на 3 =>", find([1, 2, 6, 4], x => x % 3 == 0)) 

Array.prototype.test = (x) => {
    for (let i of this) {
        this[i] *= 10
    }
    return this
}
console.log([1, 2, 3, 4].test())