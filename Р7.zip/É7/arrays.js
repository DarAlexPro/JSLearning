let a = [1, 2, 3, 4, 5]

let x = a[0]
let y = a[2]

console.log("x, y => ", x, y)

let [q, v, s] = a
console.log('After let [q, v, s] = a => ', q, v, s)

let [, t, m] = a
console.log('After let [, t, m] = a => ', t, m)

let [_, w, r] = a
console.log('After let [, w, r] = a => ', w, r)

let [d, ...o] = a
console.log('d, .... o => ', d, o)

function sum (a,b,c) {
    return a + b + c
}

console.log("sum(...a) => ", sum(...a))

function sum2 (...a) {
    return a.reduce((a, b) => a + b)
}
console.log("sum2(...a, 4, 6554,34,) => ", sum2(...a, 4, 6554,34,))

// методы работы с массивом
console.log(a)
a.push(6,7,)
console.log(a)

console.log("Что возвращает метод push?", a.push(8, 9), " - длину массива!")

console.log(a.pop())
console.log("a after pop:", a)

console.log(a.unshift(0))
console.log("a.unshift():", a)

console.log(a.shift())
console.log("a.shift():", a)

// добавление в массив, независимо от его длины
a[45] = 45
console.log(a)
console.log(a.length)

// но лучше так:
a[a.length] = 45
console.log(a)
console.log(a.length)

console.log("a.indexOf():", 5)
console.log("a.includes():", 5)
console.log("a.concat():", a.concat(a, a), a)
console.log("a.reverse():", a.reverse())
console.log("a.join():", a.join('-'))

console.log("Каскад:", "Привет мир".split('').reverse().join(''))
console.log("a.reduce():", a.reduce((a,b) => a + b))

console.log("a.every():", a.every( x => typeof x == 'number'))
a.push('a')
console.log("a.some():", a.some( x => typeof x == 'string'))
console.log("a.sort():", a.sort( (x, y) => y - x))

// ссылка на документацию 
// https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Global_Objects/Array/sort