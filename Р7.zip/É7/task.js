function calc (a, b, op) {
    if (typeof a !== 'number' || typeof b !== 'number' || typeof op !== 'string')
        return null

    let operation = {
        '+': (a, b) => a + b,
        '-': (a, b) => a - b,
        '*': (a, b) => a * b,
        '/': (a, b) => a / b,
    }
    return operation[op](a, b)
}

// errors
console.log(calc( '1', 6, '+')) //=> null
console.log(calc( 1, '6', '+')) //=> null
console.log(calc( 1, 6, 0))     //=> null

console.log(calc( 1, 6, '+'))   // => 7
console.log(calc( 1, 6, '-'))   // => -5
console.log(calc( 1, 6, '*'))   // => 6
console.log(calc( 1, 5, '/'))   // => 0.2