// строка 
let s1 = 'Привет'
let s2 = "Мир"
let s3 = `${s1}, ${s2}!`

let s4 = new String('Я строка')
console.log(s1, s2, s3)
console.log(s4)

// Свойства строк
console.log('s3.length', s3.length)
console.log('s3[s3.length-1]', s3[s3.length-1])

s3[s3.length-1] = '5'
console.log(s3)

// методы строк
console.log('s3.toUpperCase() =>', s3.toUpperCase(), s3)
console.log('s3.toLowerCase() =>', s3.toLowerCase(), s3)
console.log('s3.indexOf() =>', s3.indexOf('!'))
console.log('s3.indexOf() =>', s3.indexOf('?'))

console.log('s3.includes("Мир") =>', s3.includes('Мир'))
console.log('s3.includes("?") =>', s3.includes('?'))

console.log('Каскад =>', s3.toLowerCase().indexOf('мир'))
console.log('s3.concat("труд", "май") =>', s3.concat("\nТруд!", "\nМай!".toUpperCase()))

console.log('s3.replace =>', s3.replace('Мир', "World"))
console.log('s3.replace =>', s3.concat(s3, s3).replace('Мир', "World"))
console.log('s3.replace =>', s3.concat(s3, s3).replaceAll('Мир', "World"))

console.log('s3.trim', '         '.concat(s3, '             ').trim())
console.log('s3.trimStart', '         '.concat(s3, '             ').trimStart())
console.log('s3.trimEnd', '         '.concat(s3, '             ').trimEnd())

console.log('s3.substring', s3.substring(8))
console.log('s3.substring', s3.substring(8, 2))
console.log('s3.substring', s3.substring(0, s3.indexOf('Мир')))

console.log('s3.slice', s3.slice(-2, -1))

console.log('s3.split', s3.split(' '))
console.log('s3.split.reverse.join', s3.split(' ').reverse().join(' '))

console.log('s3.repeat', s3.repeat(3))

console.log('s3.match()', s3.concat('s').match(/\w+/g))
console.log('s3.matchAll()', ...s3.matchAll(/[А-Я]/g))

// ссылка на документацию по строкам в JavaScript
https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Global_Objects/String
