function sum(a, b) {
    if (typeof a === 'number' && typeof b === 'number') {
        return a + b
    }

    if (typeof a === 'string' && typeof b === 'string') {
        return `Конкатенация: ${a}${b}`
    }

    return null;
}

console.log(sum('a', 'b'))
console.log(sum(1, 2));

// ----- альтернативная запись функции
(function () {
    console.log('Start')
})()
// если есть () это означает, что функция должна быть вызвана сразу же. 
// очень удобно, для обозначения точки входа в программу

// в нее также можно передавать аргументы
// (function (a) {
//     console.log(a)
// })('Start')

// --- Лямбда-функции
const sumLambda = (a, b) => a + b

// Как поместить функцию в объект (ниже)
const func = {}
func.sumLambda = (a, b) => a + b

function foreach (array, action) {
    for (let item of array) {
        action(item)
    }
}

foreach ([1,2,3,4,5,6], (a) => console.log(a))

function map (array, operation) {
    let arrayCopy = []
    for (let item of array) {
        arrayCopy.push(operation(item))
    }
    return arrayCopy
}

let xx = map([1,2,3,4,5,6], (a) => a*a)
console.log(xx)

// --- фабричная функция ---
function get(index) {
    return function() {
        return index++
    }
}

const iter = get(0)
const iter2 = get(10)
console.log(iter())
console.log(iter2())
console.log(iter())
console.log(iter2())
console.log(iter())
console.log(iter2())
console.log(iter())


// -- То же только через лямбда ---
const gen2 = (index) => () => index--
const iter3 = gen2(50)
console.log(iter3())
console.log(iter3())
console.log(iter3())
console.log(iter3())
console.log(iter3())
console.log(iter3())
console.log(iter3())
console.log(iter3())

// ---- Возможность работы с аргументами функции ----
function mult () {
    let result = 1
    for (item of arguments) {
        result *= item
    }
    return result
}
console.log(mult(1,5,5,5,5,5,5,5,7))

// --- Передача аргументов по умолчанию ---
function defaultArgs(a = 0, b = 0, c = 0) {
    return a + b + c
}
console.log(`1+2=${defaultArgs(1, 2)}`)

// Запомни - в JavaScript абсолютно все является объектов (object)

// функция-конструктор
console.log("===== функция-конструктор====")
function Calc() {
    this.operation = { // метод-класса
        '+': (a, b) => a + b
    }
    this.start = function(a, b, op) { // функция-свойство класса
        return this.operation[op](a, b)
    }
}

let calc = new Calc()
console.log(calc)
console.log(calc.operation)
console.log(calc.start)
console.log(calc.start(3, 5, "+"))